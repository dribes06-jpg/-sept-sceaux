// Immutable shell version: change this identifier whenever a shipped asset changes.
const VERSION = 'e3da3bf8d18f';
// Isolate installations hosted at different GitHub Pages subpaths.
const PREFIX = 'sept-sceaux-' + encodeURIComponent(self.registration.scope) + '-';
const CACHE = PREFIX + VERSION;
const FILES = [
 "./",
 "./index.html",
 "./manifest.json",
 "./src/app.js",
 "./src/crypto.js",
 "./src/data.js",
 "./src/scene.js",
 "./src/storage.js",
 "./src/style.css",
 "./src/verifiers.js",
 "./assets/fonts/editorial.woff",
 "./assets/fonts/interface.woff",
 "./assets/vendor/three.core.min.js",
 "./assets/vendor/three.module.min.js",
 "./icons/apple-touch-icon.png",
 "./icons/icon-192.png",
 "./icons/icon-512.png",
 "./icons/icon-maskable.png",
 "./icons/seal.svg"
];
const absolute = p => new URL(p, self.registration.scope).href;
self.addEventListener('install', event => {
 event.waitUntil((async () => {
  const cache = await caches.open(CACHE);
  // Installation is atomic: activation never occurs after a partial shell download.
  await cache.addAll(FILES.map(p => new Request(absolute(p), {cache:'reload'})));
  await self.skipWaiting();
 })());
});
self.addEventListener('activate', event => {
 event.waitUntil((async () => {
  for (const name of await caches.keys()) if (name.startsWith(PREFIX) && name !== CACHE) await caches.delete(name);
  await self.clients.claim();
 })());
});
self.addEventListener('fetch', event => {
 if (event.request.method !== 'GET') return;
 const url = new URL(event.request.url);
 if (url.origin !== self.location.origin || !url.href.startsWith(self.registration.scope)) return;
 event.respondWith((async () => {
  const cache = await caches.open(CACHE);
  if (event.request.mode === 'navigate') {
   return (await cache.match(absolute('./index.html'))) || fetch(event.request);
  }
  return (await cache.match(event.request, {ignoreSearch:true})) || fetch(event.request);
 })());
});
self.addEventListener('message', event => {
 if (event.data?.type !== 'CHECK_OFFLINE') return;
 event.waitUntil((async () => {
  const cache = await caches.open(CACHE);
  const checks = await Promise.all(FILES.map(p=>cache.match(absolute(p))));
  event.ports[0]?.postMessage({type:checks.every(Boolean)?'OFFLINE_READY':'OFFLINE_INCOMPLETE',version:VERSION});
 })());
});
