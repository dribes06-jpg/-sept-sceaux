# Le Secret des Sept Sceaux

Compagnon mobile du Carnet Joueurs « Regards croisés ». Application statique, sans compilation et sans serveur applicatif. Le carnet reste nécessaire pour résoudre les énigmes. Cette application ne diffuse pas les corrigés.

## Ouvrir le projet

Le projet doit être servi en HTTPS, ou sur `localhost` pour le développement. Ouvrir `index.html` directement dans Fichiers ne permet pas les modules JavaScript, la cryptographie et le service worker nécessaires.

```sh
python3 -m http.server 8080
```

Puis ouvrir `http://localhost:8080`. Aucun `npm install` n’est nécessaire pour utiliser ou publier le jeu.

## GitHub Pages

Pour un dépôt nommé `sept-sceaux`, tous les chemins sont relatifs et conviennent à `https://UTILISATEUR.github.io/sept-sceaux/`.

- Si les fichiers sont déjà dans le dépôt : Settings → Pages → Deploy from a branch → main → /(root).
- Depuis un iPhone avec seulement le ZIP : suivre **GUIDE_IPHONE.md**. Le workflow fourni extrait le ZIP et publie les fichiers, sans décompression manuelle dans GitHub.

Aucun domaine, compte joueur, clé API ou outil payant n’est nécessaire au fonctionnement de l’application. Le dépôt et les règles GitHub Pages dépendent de votre compte GitHub.

## iPhone et hors connexion

Ouvrir l’adresse HTTPS dans Safari. Attendre « Prêt hors ligne », puis ajouter à l’écran d’accueil. Lancer ensuite l’icône avec du réseau et attendre à nouveau le statut. Tester le mode avion avant la visite. Toujours utiliser la même app/icône pendant l’enquête.

Le cache et la progression sont locaux. Effacer les données du site, supprimer l’app ou une décision du système de libérer du stockage peuvent les supprimer. La vibration est facultative et reste silencieuse lorsque le navigateur ne la prend pas en charge.

## Organisation

```text
index.html
manifest.json
service-worker.js
src/
  app.js          navigation, saisie et progression
  scene.js        Louvre procédural et repli SVG
  data.js         missions et fragments du carnet
  crypto.js       vérification et normalisation
  verifiers.js    empreintes salées
  storage.js      sauvegarde locale versionnée
  style.css       identité visuelle et responsive
assets/
  fonts/          polices locales et licence
  vendor/         Three.js 0.180.0 et licence MIT
icons/            icônes PWA, iPhone et favicon
.github/workflows/pages.yml
GUIDE_IPHONE.md
README.md
docs/
  ARCHITECTURE.md
  TESTS.md
tools/
  update-cache.py
  smoke.mjs
```

Le modèle du Louvre est procédural : pas de modèles ou textures lourds à télécharger. La carte est sectorielle et indicative ; elle ne donne pas de chemin entre salles.

## Modifier sans tout reconstruire

Conserver la structure existante et cibler le fichier concerné. Les réponses n’apparaissent pas en clair : ne pas ajouter de table de corrigés dans le JavaScript, les tests ou le dépôt public. Les valeurs saisies pour les sceaux ne sont pas conservées.

Après modification d’un fichier livré au navigateur, renouveler la version du cache :

```sh
python3 tools/update-cache.py
```

Ce script régénère la liste des fichiers et une version fondée sur leurs contenus. Sans Python, modifier manuellement la constante `VERSION` et, si nécessaire, `FILES` dans `service-worker.js`.

## Tests

Voir `docs/TESTS.md` pour le bilan réel, les limites et la liste d’essais à refaire sur iPhone. Le script `tools/smoke.mjs` accepte un fichier de fixtures **privé et extérieur au dépôt** ; aucune clé n’est livrée avec les tests. Playwright n’est qu’une dépendance de développement.

## Sécurité des réponses

SHA-256 salé évite des réponses lisibles directement dans le code. Cela n’empêche pas une analyse exhaustive de 25 valeurs ni une modification volontaire du stockage local. Le programme ne prétend pas garantir un secret ou une protection anti-triche forte. Le message final doit toujours être déchiffré et saisi par les joueurs.

## Attribution

Conception indépendante du musée du Louvre, pour une visite privée. Données des missions issues du carnet fourni. Bibliothèques et polices : licences incluses dans `assets`. Aucun traceur, publicité ou requête vers un service tiers à l’exécution.
