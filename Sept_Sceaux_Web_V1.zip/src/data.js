// Référence : Carnet Joueurs, édition Regards croisés, 12 pages.
// Coordonnées sectorielles schématiques, jamais un guidage dans les couloirs.
export const missions = [
 { id:1, title:'L’anatomie du gardien', object:'Sphinx de Tanis', wing:'Sully', level:-1, room:'338', page:5, position:[5.7,-3,3.65], mood:'Sous la pierre, un premier gardien attend votre regard.' },
 { id:2, title:'Le cycle des récoltes', object:'Mastaba d’Akhethétep', wing:'Sully', level:0, room:'333', page:6, position:[7.6,0,3.65], mood:'Les gestes des vivants traversent la maison des morts.' },
 { id:3, title:'Le miroir de Sekhmet', object:'Sekhmet', wing:'Sully', level:0, room:'324', page:7, position:[9,0,-.4], mood:'Deux présences, une même puissance. Reliez vos observations.' },
 { id:4, title:'Trois témoins, trois sceaux', object:'Scribe / Sépa / Nésa', wing:'Sully', level:1, room:'635', page:8, position:[9,3,-2], mood:'Trois témoins gardent un accord que seul le regard peut retrouver.' },
 { id:5, title:'L’équilibre du juge', object:'Code de Hammurabi', wing:'Richelieu', level:0, room:'227', page:9, position:[.3,0,-3.8], mood:'L’image et la règle doivent retrouver leur juste équilibre.' },
 { id:6, title:'Le lion et le gardien ailé', object:'Taureau ailé / héros au lion', wing:'Richelieu', level:0, room:'229', page:10, position:[2,0,-2.4], mood:'Le palais ne livre pas tous ses secrets depuis un seul point de vue.' },
 { id:7, title:'Le fragment retrouvé', object:'Victoire de Samothrace', wing:'Denon', level:1, room:'703', page:11, position:[1.1,3,3.8], mood:'Un fragment séparé peut rendre sa voix à tout un monument.' }
];
export const visitOrder = [1,2,3,5,6,4,7];
export const fragments = ['OHV','XNDEANB','WI','KXIHGWXGM','YCIVL','FE','ANEQDHQ'];
