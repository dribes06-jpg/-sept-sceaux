import * as THREE from '../assets/vendor/three.module.min.js';
import {missions} from './data.js';
const reduced=matchMedia('(prefers-reduced-motion: reduce)');
const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
const GOLD=0xd3b47c;
// A deliberately schematic footprint based on the exploded map in the booklet.
const blocks=[
 [-3.35,-3.8,12.6,1.35,'Richelieu'],[-4.1,3.8,14.1,1.35,'Denon'],
 [6.15,-3.8,7.4,1.35,'Sully'],[6.15,3.8,7.4,1.35,'Sully'],
 [9.15,0,1.35,6.25,'Sully'],[3.15,0,1.35,6.25,'Sully'],
 [-8.6,-3.8,1.7,2.1,'Richelieu'],[-10.5,3.8,1.6,2.1,'Denon'],
 [2.2,-3.8,1.8,2.1,'Richelieu'],[2.2,3.8,1.8,2.1,'Denon'],
 [9.1,-3.7,1.85,1.9,'Sully'],[9.1,3.7,1.85,1.9,'Sully']
];
export class LouvreScene {
 constructor({canvas,container,onSelect,onQuality}) {
  this.canvas=canvas;this.container=container;this.onSelect=onSelect;this.onQuality=onQuality;
  this.eco=false;this.autoLow=false;this.reduced=reduced.matches;this.active=true;this.dirty=true;
  this.selected=null;this.level='all';this.validated=[];this.yaw=.36;this.pitch=.63;this.zoom=1;
  this.target=new THREE.Vector3(0,0,0);this.goalTarget=this.target.clone();this.goalZoom=1;
  this.pointerMap=new Map();this.dragged=false;this.ceremonyStart=0;this.pulseAt=0;
  this.makeDOM();
  try {
   this.renderer=new THREE.WebGLRenderer({canvas,alpha:true,antialias:true,powerPreference:'low-power'});
   this.renderer.setPixelRatio(Math.min(devicePixelRatio,1.6));this.renderer.setClearColor(0x081b23,0);
   this.scene=new THREE.Scene();this.camera=new THREE.OrthographicCamera(-10,10,10,-10,.1,180);
   this.world=new THREE.Group();this.scene.add(this.world);this.floors=[];
   for(const [level,y] of [[-1,-3],[0,0],[1,3]])this.addFloor(level,y);
   this.addPyramid();this.addGround();this.addDust();this.addFinalLines();
   this.resizeObserver=new ResizeObserver(()=>this.resize());this.resizeObserver.observe(container);
   this.bindGestures();this.resize();
   canvas.addEventListener('webglcontextlost',event=>{event.preventDefault();this.fallback('Carte allégée');});
   document.addEventListener('visibilitychange',()=>{this.dirty=true;this.lastTime=0;});
   reduced.addEventListener('change',e=>{this.reduced=e.matches;this.dirty=true;});
   this.frame=this.frame.bind(this);this.raf=requestAnimationFrame(this.frame);
  }catch(error){console.warn('Vue 3D indisponible : carte schématique activée.');this.fallback('Carte allégée');}
 }
 makeDOM(){
  const host=document.querySelector('#markers'),leaders=document.querySelector('#leaders');
  this.markers=missions.map(m=>{
   const button=document.createElement('button');button.className='map-marker';button.dataset.mission=m.id;button.textContent=String(m.id).padStart(2,'0');button.setAttribute('aria-label',`Sceau ${m.id} : ${m.object}, ${m.wing}, niveau ${m.level}, salle ${m.room}`);
   button.addEventListener('click',()=>this.onSelect(m.id));host.append(button);
   const line=document.createElementNS('http://www.w3.org/2000/svg','line');leaders.append(line);
   return {mission:m,button,line,anchor:new THREE.Vector3(m.position[0],m.position[1]+.95,m.position[2])};
  });
  const labels=[['RICHELIEU',[-5,3.9,-4.6]],['DENON',[-6.5,3.9,4.9]],['SULLY',[9.4,3.9,0]],['Cour Napoléon',[-2,-3.15,0]],['Cour Carrée',[6.1,3.2,0]]];
  this.labels=labels.map(([text,xyz])=>{const el=document.createElement('span');el.className='map-label'+(text.startsWith('Cour')?' courtyard':'');el.textContent=text;document.querySelector('#map-labels').append(el);return{el,point:new THREE.Vector3(...xyz)};});
 }
 addFloor(level,y){
  const positions=[],lines=[],colors=[];
  const addLine=(a,b)=>lines.push(...a,...b);
  for(const [x,z,w,d,wing] of blocks){
   const h=(w<2? .88:.46);const geom=new THREE.BoxGeometry(w,h,d).toNonIndexed();
   geom.translate(x,y+h/2,z);positions.push(...geom.attributes.position.array);geom.dispose();
   const x0=x-w/2,x1=x+w/2,z0=z-d/2,z1=z+d/2,y0=y,y1=y+h;
   const corners=[[x0,y0,z0],[x1,y0,z0],[x1,y0,z1],[x0,y0,z1],[x0,y1,z0],[x1,y1,z0],[x1,y1,z1],[x0,y1,z1]];
   for(const [a,b] of [[0,1],[1,2],[2,3],[3,0],[4,5],[5,6],[6,7],[7,4],[0,4],[1,5],[2,6],[3,7]])addLine(corners[a],corners[b]);
   // Rhythmic façade bays add architectural character with a single line batch.
   for(let px=x0+.35;px<x1-.2;px+=.48){addLine([px,y+.08,z1+.008],[px,y+h-.08,z1+.008]);addLine([px,y+.08,z0-.008],[px,y+h-.08,z0-.008]);}
   if(d>3)for(let pz=z0+.35;pz<z1-.2;pz+=.48){addLine([x1+.008,y+.08,pz],[x1+.008,y+h-.08,pz]);}
  }
  const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));
  const mat=new THREE.MeshBasicMaterial({color:level===1?0x457d80:0x2d6472,transparent:true,opacity:level===-1?.06:.13,depthWrite:false,side:THREE.DoubleSide});
  const mesh=new THREE.Mesh(geometry,mat);this.world.add(mesh);
  const lineGeom=new THREE.BufferGeometry();lineGeom.setAttribute('position',new THREE.Float32BufferAttribute(lines,3));
  const lineMat=new THREE.LineBasicMaterial({color:level===1?0x81b9b6:0x64939b,transparent:true,opacity:level===-1?.3:.58,depthWrite:false});
  const edges=new THREE.LineSegments(lineGeom,lineMat);this.world.add(edges);
  this.floors.push({level,mat,lineMat,mesh,edges,base:mat.opacity,lineBase:lineMat.opacity});
 }
 addPyramid(){
  const g=new THREE.ConeGeometry(2.1,2.5,4,1,true);g.rotateY(Math.PI/4);g.translate(-2,1.35,0);
  const mat=new THREE.MeshBasicMaterial({color:GOLD,transparent:true,opacity:.12,side:THREE.DoubleSide,depthWrite:false});
  this.pyramid=new THREE.Mesh(g,mat);this.world.add(this.pyramid);
  const lines=[];const apex=new THREE.Vector3(-2,2.6,0),corners=[[-3.485,.1,-1.485],[-.515,.1,-1.485],[-.515,.1,1.485],[-3.485,.1,1.485]].map(v=>new THREE.Vector3(...v));
  for(let face=0;face<4;face++){
   const a=corners[face],b=corners[(face+1)%4];
   for(let j=0;j<=7;j++){
    const t=j/7;const edgeA=apex.clone().lerp(a,t),edgeB=apex.clone().lerp(b,t);lines.push(...edgeA.toArray(),...edgeB.toArray());
    const base=a.clone().lerp(b,t);lines.push(...apex.toArray(),...base.toArray());
   }
  }
  const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(lines,3));
  this.pyramidEdges=new THREE.LineSegments(geo,new THREE.LineBasicMaterial({color:0xe2c68b,transparent:true,opacity:.72,depthWrite:false}));this.world.add(this.pyramidEdges);
  const beam=new THREE.Mesh(new THREE.CylinderGeometry(.1,1.45,7,16,1,true),new THREE.MeshBasicMaterial({color:0xe2c58d,opacity:.018,transparent:true,depthWrite:false,side:THREE.DoubleSide}));beam.position.set(-2,4.2,0);this.world.add(beam);this.beam=beam;
 }
 addGround(){
  const positions=[];
  for(let x=-12;x<=12;x+=2)positions.push(x,-3.5,-7,x,-3.5,7);
  for(let z=-6;z<=6;z+=2)positions.push(-12,-3.5,z,12,-3.5,z);
  const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));
  this.world.add(new THREE.LineSegments(g,new THREE.LineBasicMaterial({color:0x406775,opacity:.18,transparent:true,depthWrite:false})));
  for(const radius of [5.8,7.5,10.6]){
   const pts=[];for(let i=0;i<=100;i++){const a=i/100*Math.PI*2;pts.push(new THREE.Vector3(Math.cos(a)*radius,-3.48,Math.sin(a)*radius*.64));}
   const ring=new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts),new THREE.LineBasicMaterial({color:GOLD,transparent:true,opacity:.09,depthWrite:false}));this.world.add(ring);
  }
  // Projection guides connect exploded floors, without suggesting visitor routes.
  const guides=[];for(const [x,z] of [[-10.5,3.8],[9.8,4.5],[9.8,-4.5],[2,-4.5]])guides.push(x,-3.4,z,x,4.2,z);
  const guideGeo=new THREE.BufferGeometry();guideGeo.setAttribute('position',new THREE.Float32BufferAttribute(guides,3));
  this.world.add(new THREE.LineSegments(guideGeo,new THREE.LineBasicMaterial({color:GOLD,opacity:.13,transparent:true,depthWrite:false})));
  const pulseG=new THREE.RingGeometry(.95,1,64);pulseG.rotateX(-Math.PI/2);
  this.pulse=new THREE.Mesh(pulseG,new THREE.MeshBasicMaterial({color:GOLD,transparent:true,opacity:0,depthWrite:false,side:THREE.DoubleSide}));this.pulse.position.set(-2,-3.35,0);this.scene.add(this.pulse);
 }
 addDust(){
  const positions=[];for(let i=0;i<45;i++)positions.push((Math.random()-.5)*25,Math.random()*11-3,(Math.random()-.5)*14);
  const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));
  this.dust=new THREE.Points(g,new THREE.PointsMaterial({color:0xe7c889,size:.04,transparent:true,opacity:.4,depthWrite:false,sizeAttenuation:true}));this.scene.add(this.dust);
 }
 addFinalLines(){
  const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(new Float32Array(7*2*3),3));
  this.finalLines=new THREE.LineSegments(g,new THREE.LineBasicMaterial({color:GOLD,transparent:true,opacity:0,depthWrite:false}));this.scene.add(this.finalLines);
 }
 resize(){if(this.isFallback)return;const rect=this.container.getBoundingClientRect();if(!rect.width||!rect.height)return;this.width=rect.width;this.height=rect.height;const aspect=rect.width/rect.height;this.halfHeight=Math.max(8.7,12.5/aspect);this.renderer.setSize(rect.width,rect.height,false);this.camera.left=-this.halfHeight*aspect;this.camera.right=this.halfHeight*aspect;this.camera.top=this.halfHeight;this.camera.bottom=-this.halfHeight;this.camera.updateProjectionMatrix();this.dirty=true;}
 bindGestures(){
  const c=this.canvas;
  c.addEventListener('pointerdown',e=>{if(e.button!==0)return;this.pointerMap.set(e.pointerId,{x:e.clientX,y:e.clientY});c.setPointerCapture(e.pointerId);this.dragged=false;this.dirty=true;});
  c.addEventListener('pointermove',e=>{
   const last=this.pointerMap.get(e.pointerId);if(!last)return;
   if(this.pointerMap.size===2){
    const other=[...this.pointerMap.entries()].find(([id])=>id!==e.pointerId)?.[1];
    if(other){const before=Math.hypot(last.x-other.x,last.y-other.y),after=Math.hypot(e.clientX-other.x,e.clientY-other.y);if(before>5)this.goalZoom=clamp(this.goalZoom*(after/before),.8,1.55);}
   }else{this.yaw=clamp(this.yaw-(e.clientX-last.x)*.004,-.4,.95);this.pitch=clamp(this.pitch+(e.clientY-last.y)*.002,.42,.9);}
   this.pointerMap.set(e.pointerId,{x:e.clientX,y:e.clientY});this.dragged=true;this.dirty=true;
  });
  const end=e=>{this.pointerMap.delete(e.pointerId);};c.addEventListener('pointerup',end);c.addEventListener('pointercancel',end);c.addEventListener('lostpointercapture',end);
  c.addEventListener('wheel',e=>{e.preventDefault();this.goalZoom=clamp(this.goalZoom-e.deltaY*.001,.8,1.55);this.dirty=true;},{passive:false});
 }
 setActive(active){this.active=active;this.dirty=true;}
 setQuality(eco){this.eco=eco;document.body.classList.toggle('eco',eco);if(this.renderer&&!this.isFallback)this.renderer.setPixelRatio(eco||this.autoLow?1:Math.min(devicePixelRatio,1.6));this.dirty=true;}
 filter(level){this.level=level;this.selected=null;this.resetCamera(false);this.dirty=true;this.updateVisibility();}
 select(id){this.selected=id;this.level='all';const m=missions.find(m=>m.id===id);if(m){this.goalTarget.set(m.position[0]*.43,m.position[1]*.75,m.position[2]*.3);this.goalZoom=1.12;}else this.resetCamera();this.dirty=true;this.updateVisibility();}
 resetCamera(clearSelection=true){this.yaw=.36;this.pitch=.63;this.goalZoom=1;this.goalTarget?.set(0,0,0);if(clearSelection)this.selected=null;this.dirty=true;this.updateVisibility();}
 setValidated(ids){this.validated=ids;this.markers.forEach(({mission,button})=>{button.classList.toggle('validated',ids.includes(mission.id));button.setAttribute('aria-label',`Sceau ${mission.id} : ${mission.object}, ${mission.wing}, niveau ${mission.level}, salle ${mission.room}${ids.includes(mission.id)?', authentifié':''}`);});this.dirty=true;}
 unlock(id){this.setValidated([...new Set([...this.validated,id])]);const marker=this.markers[id-1];marker.button.classList.add('just-opened');setTimeout(()=>marker.button.classList.remove('just-opened'),1700);this.pulseAt=performance.now();this.dirty=true;}
 celebrate(){this.selected=null;this.level='all';this.resetCamera();this.ceremonyStart=performance.now();this.dirty=true;this.updateVisibility();}
 endCelebrate(){this.ceremonyStart=0;if(this.finalLines)this.finalLines.material.opacity=0;this.dirty=true;}
 updateVisibility(){
  this.markers.forEach(({mission,button,line})=>{const visible=this.level==='all'||mission.level===Number(this.level);button.hidden=!visible;line.style.display=visible?'':'none';button.classList.toggle('selected',mission.id===this.selected);});
  if(this.isFallback)this.layoutFallback();
 }
 project(point){const v=point.clone().project(this.camera);return {x:(v.x+1)*this.width/2,y:(1-v.y)*this.height/2};}
 layoutMarkers(now){
  let points=this.markers.map(({anchor,mission})=>{
   if(this.ceremonyStart){const a=(mission.id-1)/7*Math.PI*2-.5*Math.PI,t=clamp((now-this.ceremonyStart)/1600,0,1);const ring=new THREE.Vector3(Math.cos(a)*9,3+Math.sin(a)*3,Math.sin(a)*4);return anchor.clone().lerp(ring,t);}
   return anchor;
  });
  const projected=points.map(p=>this.project(p));
  const places=projected.map(p=>({...p}));
  const shown=this.markers.map(m=>!m.button.hidden);
  // Keep 44px touch targets separated. Thin leaders retain the real anchor.
  for(let pass=0;pass<8;pass++)for(let i=0;i<places.length;i++)for(let j=i+1;j<places.length;j++){
   if(!shown[i]||!shown[j])continue;let dx=places[j].x-places[i].x,dy=places[j].y-places[i].y;const distance=Math.hypot(dx,dy);
   if(distance<48){if(distance<.1){dx=1;dy=0;}const shift=(48-distance)/2;const div=Math.max(distance,.1);places[i].x-=dx/div*shift;places[i].y-=dy/div*shift;places[j].x+=dx/div*shift;places[j].y+=dy/div*shift;}
  }
  this.markers.forEach(({button,line},i)=>{const p=places[i],a=projected[i];p.x=clamp(p.x,25,this.width-25);p.y=clamp(p.y,24,this.height-26);button.style.left=p.x+'px';button.style.top=p.y+'px';line.setAttribute('x1',a.x);line.setAttribute('y1',a.y);line.setAttribute('x2',p.x);line.setAttribute('y2',p.y+9);});
  this.labels.forEach(({el,point})=>{const p=this.project(point);el.style.left=p.x+'px';el.style.top=p.y+'px';el.hidden=this.selected!==null||this.ceremonyStart>0||p.x<22||p.x>this.width-22||p.y<10||p.y>this.height-15;});
  if(this.ceremonyStart){const arr=this.finalLines.geometry.attributes.position;for(let i=0;i<7;i++){arr.setXYZ(i*2,points[i].x,points[i].y,points[i].z);const b=points[(i+1)%7];arr.setXYZ(i*2+1,b.x,b.y,b.z);}arr.needsUpdate=true;this.finalLines.material.opacity=clamp((now-this.ceremonyStart-500)/1600,0,.5);}
 }
 frame(now){
  this.raf=requestAnimationFrame(this.frame);if(this.isFallback||document.hidden||!this.active)return;
  const low=this.eco||this.autoLow;const quiet=this.reduced||low;
  if(quiet && now-(this.lastRender||0)<33)return;
  const transitioning=this.target.distanceTo(this.goalTarget)>.005||Math.abs(this.zoom-this.goalZoom)>.001;
  if(this.reduced&&!this.dirty&&!transitioning&&!this.pulseAt&&!this.ceremonyStart)return;
  const dt=this.lastRender?now-this.lastRender:16;this.lastRender=now;
  if(!low && !this.reduced && dt<200){this.samples=(this.samples||0)+1;this.totalMs=(this.totalMs||0)+dt;if(this.samples===150){if(this.totalMs/150>28){this.autoLow=true;this.renderer.setPixelRatio(1);this.onQuality?.('allégé automatiquement');}this.samples=0;this.totalMs=0;}}
  const ease=this.reduced?1:1-Math.exp(-Math.min(dt,100)/180);this.target.lerp(this.goalTarget,ease);this.zoom+=(this.goalZoom-this.zoom)*ease;
  const sway=quiet||this.pointerMap.size||this.selected?0:Math.sin(now*.00016)*.014;
  const yaw=this.yaw+sway,r=40,cp=Math.cos(this.pitch);
  this.camera.position.set(this.target.x+Math.sin(yaw)*r*cp,this.target.y+Math.sin(this.pitch)*r,this.target.z+Math.cos(yaw)*r*cp);this.camera.lookAt(this.target);this.camera.zoom=this.zoom;this.camera.updateProjectionMatrix();this.camera.updateMatrixWorld();
  const selectedLevel=this.selected?missions[this.selected-1].level:null;
  for(const floor of this.floors){const focused=(selectedLevel===null||floor.level===selectedLevel)&&(this.level==='all'||Number(this.level)===floor.level);const alpha=focused?1:.1;floor.mat.opacity+=(floor.base*alpha-floor.mat.opacity)*ease;floor.lineMat.opacity+=(floor.lineBase*alpha-floor.lineMat.opacity)*ease;}
  this.dust.visible=!quiet;this.beam.visible=!low;this.dust.rotation.y=quiet?0:now*.000008;
  this.pyramidEdges.material.opacity=.72+(quiet?0:Math.sin(now*.001)*.08);
  if(this.pulseAt){const t=(now-this.pulseAt)/1700;this.pulse.scale.setScalar(1+t*13);this.pulse.material.opacity=this.reduced?0:Math.max(0,.45*(1-t));if(t>=1)this.pulseAt=0;}
  this.layoutMarkers(now);this.renderer.render(this.scene,this.camera);this.dirty=false;
 }
 fallback(label){
  if(this.isFallback)return;this.isFallback=true;if(this.raf)cancelAnimationFrame(this.raf);this.canvas.hidden=true;this.renderer?.dispose();this.labels.forEach(l=>l.el.hidden=true);document.querySelector('#leaders').style.display='none';
  const ns='http://www.w3.org/2000/svg';const svg=document.createElementNS(ns,'svg');svg.setAttribute('viewBox','0 0 500 390');svg.setAttribute('aria-label','Plan éclaté schématique du Louvre');svg.classList.add('fallback-map');
  let markup='';for(const [level,offset] of [[1,24],[0,144],[-1,264]]){markup+=`<g transform="translate(30 ${offset})"><text x="0" y="0">NIVEAU ${level}</text><path d="M40 18H280V44H40zM0 83H280v25H0zM280 18h145v90H280v-25h112V44H280zM280 44h26v39h-26z"/><path d="m150 58 23-21 23 21-23 12z" fill="none"/></g>`;}svg.innerHTML=markup;this.container.insertBefore(svg,this.canvas);this.fallbackSVG=svg;this.onQuality?.(label);this.resizeObserver?.disconnect();this.resizeObserver=new ResizeObserver(()=>this.layoutFallback());this.resizeObserver.observe(this.container);this.layoutFallback();
 }
 layoutFallback(){
  const rect=this.container.getBoundingClientRect();const scale=Math.min(rect.width/500,rect.height/390),ox=(rect.width-500*scale)/2,oy=(rect.height-390*scale)/2;
  const anchors=[[372,366],[404,248],[453,205],[453,72],[250,160],[315,199],[266,127]];
  this.markers.forEach(({button},i)=>{button.style.left=(ox+anchors[i][0]*scale)+'px';button.style.top=(oy+anchors[i][1]*scale)+'px';});
 }
}
