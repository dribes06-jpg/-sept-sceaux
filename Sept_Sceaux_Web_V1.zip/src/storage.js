export const STORAGE_KEY='sept-sceaux.progress.v1';
export const fresh=()=>({version:1,startedAt:new Date().toISOString(),introSeen:false,validated:[],finalSeen:false,completed:false,drafts:Array(7).fill(''),proofs:'',quality:'auto'});
let writable=true;
export function sanitize(data) {
 const s=fresh();if(!data || data.version!==1)return s;
 s.startedAt=typeof data.startedAt==='string' && !isNaN(Date.parse(data.startedAt))?data.startedAt:s.startedAt;
 s.introSeen=data.introSeen===true;
 s.validated=[...new Set((Array.isArray(data.validated)?data.validated:[]).filter(n=>Number.isInteger(n)&&n>=1&&n<=7))].sort((a,b)=>a-b);
 s.finalSeen=s.validated.length===7&&data.finalSeen===true;
 s.completed=s.validated.length===7&&data.completed===true;
 s.drafts=s.drafts.map((_,i)=>typeof data.drafts?.[i]==='string'?data.drafts[i].slice(0,40):'');
 s.proofs=typeof data.proofs==='string'?data.proofs.slice(0,1500):'';
 s.quality=['auto','eco'].includes(data.quality)?data.quality:'auto';return s;
}
export function load() {try {return sanitize(JSON.parse(localStorage.getItem(STORAGE_KEY)));}catch {return fresh();}}
export function save(state) {try {localStorage.setItem(STORAGE_KEY,JSON.stringify(state));writable=true;}catch {writable=false;}return writable;}
export function canSave(){return writable;}
