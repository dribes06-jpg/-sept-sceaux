import {seals, ending} from './verifiers.js';
export function normalizeKey(value) {
 const s=String(value).trim();
 if(!/^\d{1,2}$/.test(s)) return null;
 const n=Number(s);return n>=1 && n<=25 ? String(n) : null;
}
export function normalizeMessage(value) {
 return String(value).replace(/œ/gi,'oe').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toUpperCase().replace(/[^A-Z\s]/g,' ').trim().replace(/\s+/g,' ');
}
async function check(scope,id,entry,value) {
 if(!globalThis.crypto?.subtle) throw new Error('CRYPTO_UNAVAILABLE');
 const bytes=new TextEncoder().encode(`sept-sceaux:v1:${scope}:${id}:${entry.salt}:${value}`);
 const hash=await crypto.subtle.digest('SHA-256',bytes);
 const hex=Array.from(new Uint8Array(hash),b=>b.toString(16).padStart(2,'0')).join('');
 let mismatch=0;for(let i=0;i<hex.length;i++)mismatch|=hex.charCodeAt(i)^entry.digest.charCodeAt(i);
 return mismatch===0;
}
export async function verifyKey(id,value) {
 const key=normalizeKey(value);if(key===null || !Number.isInteger(id)||id<1||id>7)return false;
 return check('mission',id,seals[id-1],key);
}
export async function verifyMessage(value) {return check('final',0,ending,normalizeMessage(value));}
