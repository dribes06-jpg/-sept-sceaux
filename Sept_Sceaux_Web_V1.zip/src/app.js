import {missions,visitOrder,fragments} from './data.js';
import {normalizeKey,verifyKey,verifyMessage,normalizeMessage} from './crypto.js';
import {load,save,fresh,STORAGE_KEY} from './storage.js';
import {LouvreScene} from './scene.js';
const $=s=>document.querySelector(s);
let state=load(),selected=null,busy=false,epoch=0,offlineReady=false,scene,currentView='carte',introTimer,leavingIntro=false;
const reduced=matchMedia('(prefers-reduced-motion: reduce)');
function persist(){const ok=save(state);$('#storage-warning').hidden=ok;return ok;}
function haptic(){try{navigator.vibrate?.(22);}catch{}}
let toastTimer;
function toast(text){clearTimeout(toastTimer);$('#toast').textContent=text;$('#toast').hidden=false;toastTimer=setTimeout(()=>$('#toast').hidden=true,5000);}
function icon(id){return `<svg aria-hidden="true"><use href="#${id}"/></svg>`;}
function locationLabel(m){return `${m.wing} · Niveau ${m.level===-1?'−1':m.level} · Salle ${m.room}`;}
function renderList(){
 const list=$('#mission-list');list.replaceChildren();
 for(const id of visitOrder){const m=missions[id-1],done=state.validated.includes(id);const b=document.createElement('button');b.className='mission-row'+(done?' validated':'');b.dataset.mission=id;b.setAttribute('aria-label',`Sceau ${id}, ${m.object}${done?', authentifié':''}`);b.innerHTML=`<span class="mini-seal">${String(id).padStart(2,'0')}</span><span class="row-copy"><strong>${m.object}</strong><small>${locationLabel(m)} · Carnet p. ${m.page}</small><span class="row-state">${done?'AUTHENTIFIÉ':'À EXPLORER'}</span></span>${icon('arrow-icon')}`;b.addEventListener('click',()=>openMission(id));list.append(b);}
}
function render(){
 const count=state.validated.length;
 $('#progress-label').textContent=`${count} / 7 SCEAUX AUTHENTIFIÉS`;$('#progress-fill').style.width=`${count/7*100}%`;
 $('.final-count').textContent=`${count} / 7 SCEAUX AUTHENTIFIÉS`;
 $('#final-locked').hidden=count===7;$('#final-open').hidden=count!==7;$('#final-dot').hidden=count!==7;
 $('#final-form').hidden=state.completed;$('#ending').hidden=!state.completed;
 if(state.completed)$('#your-message').textContent=state.drafts.join(' ');
 const next=visitOrder.find(id=>!state.validated.includes(id));
 if(next){const m=missions[next-1];$('#next-mission').dataset.mission=next;$('#next-name').textContent=m.object;$('#next-location').textContent=locationLabel(m);$('#next-number').textContent=String(next).padStart(2,'0');$('#next-mission .eyebrow').textContent='PROCHAINE ÉTAPE CONSEILLÉE';}
 else{$('#next-mission').dataset.mission='final';$('#next-name').textContent=state.completed?'L’enquête est accomplie':'Le message de l’archiviste';$('#next-location').textContent='Les archives sont ouvertes · Carnet p. 12';$('#next-number').textContent='VII';$('#next-mission .eyebrow').textContent='LES SEPT SCEAUX SONT ROMPUS';}
 scene?.setValidated(state.validated);renderList();$('#eco-mode').checked=state.quality==='eco';
}
function navigate(view,changeHash=true){
 if(!['carte','sceaux','final'].includes(view))view='carte';
 currentView=view;$('#map-view').hidden=view!=='carte';$('#seals-view').hidden=view!=='sceaux';$('#final-view').hidden=view!=='final';
 document.querySelectorAll('nav [data-nav]').forEach(b=>{if(b.dataset.nav===view)b.setAttribute('aria-current','page');else b.removeAttribute('aria-current');});
 scene?.setActive(view==='carte');if(view==='carte')scene?.resize();
 if(changeHash&&location.hash!==`#${view}`)history.pushState(null,'',`#${view}`);
}
window.addEventListener('popstate',()=>{if($('#mission-dialog').open)$('#mission-dialog').close();navigate(location.hash.slice(1),false);});
document.querySelectorAll('[data-nav]').forEach(b=>b.addEventListener('click',()=>navigate(b.dataset.nav)));
$('.brand').addEventListener('click',e=>{e.preventDefault();navigate('carte');});
$('#next-mission').addEventListener('click',()=>{const id=$('#next-mission').dataset.mission;if(id==='final')navigate('final');else openMission(Number(id));});
function openMission(id){
 if(!missions[id-1])return;epoch++;busy=false;selected=id;const m=missions[id-1];
 scene?.select(id);document.querySelectorAll('[data-level]').forEach(b=>b.setAttribute('aria-pressed',b.dataset.level==='all'?'true':'false'));
 $('#mission-id').textContent=String(id).padStart(2,'0');$('#mission-kicker').textContent=`SCEAU ${String(id).padStart(2,'0')}`;$('#mission-title').textContent=m.title;
 $('#mission-location').textContent=locationLabel(m);$('#mission-mood').textContent=m.mood;$('#mission-page').textContent=`Résolvez la mission dans votre carnet · page ${m.page}.`;
 $('#key-input').value='';$('#submit-key').disabled=false;$('#key-feedback').textContent='';$('#key-feedback').className='feedback';
 const done=state.validated.includes(id);$('#mission-dialog').classList.toggle('authenticated',done);$('#key-form').hidden=done;$('#mission-done').hidden=!done;
 if(done){$('#key-feedback').textContent='SCEAU AUTHENTIFIÉ';$('#key-feedback').classList.add('success');}
 $('#mission-dialog').showModal();
}
$('#key-form').addEventListener('submit',async e=>{
 e.preventDefault();if(busy||selected===null)return;
 const value=$('#key-input').value;const feedback=$('#key-feedback');
 if(normalizeKey(value)===null){feedback.textContent='Saisissez une clé entière de 1 à 25.';feedback.className='feedback error';return;}
 const id=selected,token=epoch;busy=true;$('#submit-key').disabled=true;feedback.textContent='';
 try {
  const ok=await verifyKey(id,value);if(epoch!==token||selected!==id)return;
  $('#key-input').value='';
  if(ok){state.validated=[...new Set([...state.validated,id])].sort((a,b)=>a-b);const saved=persist();render();haptic();scene?.unlock(id);$('#mission-dialog').classList.add('authenticated');$('#key-form').hidden=true;$('#mission-done').hidden=false;feedback.textContent='SCEAU AUTHENTIFIÉ';feedback.className='feedback success';$('#mission-done').focus({preventScroll:true});if(!saved)toast('Sceau authentifié, mais sauvegarde locale indisponible sur cet appareil.');}
  else{feedback.textContent='LE SCEAU DEMEURE FERMÉ';feedback.className='feedback error';$('#key-input').focus({preventScroll:true});}
 }catch{if(epoch===token){feedback.textContent='La vérification est indisponible. Ouvrez le jeu depuis son adresse HTTPS.';feedback.className='feedback error';}}
 finally{if(epoch===token){busy=false;$('#submit-key').disabled=false;}}
});
$('#mission-done').addEventListener('click',()=>{$('#mission-dialog').close();navigate('carte');});
$('#mission-dialog').addEventListener('close',()=>{selected=null;epoch++;busy=false;scene?.select(null);if(state.validated.length===7&&!state.finalSeen)startCeremony();});
for(const dialog of document.querySelectorAll('dialog')){
 dialog.querySelectorAll('.close-dialog').forEach(b=>b.addEventListener('click',()=>dialog.close()));
 dialog.addEventListener('click',e=>{if(e.target!==dialog)return;const r=dialog.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom){if(dialog.id!=='ceremony-dialog')dialog.close();}});
}
$('#ceremony-dialog').addEventListener('cancel',e=>{e.preventDefault();finishCeremony();});
function startCeremony(){navigate('carte');scene?.celebrate();if(!$('#ceremony-dialog').open)$('#ceremony-dialog').showModal();}
function finishCeremony(){state.finalSeen=true;persist();$('#ceremony-dialog').close();scene?.endCelebrate();navigate('final');}
$('#enter-final').addEventListener('click',finishCeremony);
for(let i=0;i<7;i++){
 const row=document.createElement('div');row.className='fragment';row.innerHTML=`<span>${String(i+1).padStart(2,'0')}</span><div><label for="word-${i}"><span>${fragments[i]}</span><small>SCEAU ${String(i+1).padStart(2,'0')}</small></label><input id="word-${i}" type="text" maxlength="40" autocomplete="off" autocapitalize="characters" spellcheck="false" placeholder="Votre mot déchiffré" aria-label="Mot déchiffré du sceau ${i+1}"></div>`;
 const input=row.querySelector('input');input.value=state.drafts[i];input.addEventListener('input',()=>{state.drafts[i]=input.value;state.completed=false;persist();$('#final-feedback').textContent='';});$('#fragment-fields').append(row);
}
$('#proofs').value=state.proofs;$('#proofs').addEventListener('input',()=>{state.proofs=$('#proofs').value;persist();});
$('#final-form').addEventListener('submit',async e=>{
 e.preventDefault();if(state.validated.length!==7||busy)return;const token=epoch;busy=true;$('#submit-final').disabled=true;
 try{
  const value=state.drafts.join(' ');const complete=state.drafts.every(word=>/^[A-Z]+$/.test(normalizeMessage(word)));const ok=complete && await verifyMessage(value);if(token!==epoch)return;
  if(ok){state.completed=true;persist();render();haptic();$('#final-view').scrollTo({top:0,behavior:reduced.matches?'instant':'smooth'});}
  else{$('#final-feedback').textContent='LE MESSAGE RESTE SCELLÉ';$('#final-feedback').className='feedback error';}
 }catch{$('#final-feedback').textContent='La vérification est indisponible. Ouvrez le jeu depuis son adresse HTTPS.';}
 finally{if(token===epoch){busy=false;$('#submit-final').disabled=false;}}
});
$('#open-settings').addEventListener('click',()=>$('#settings-dialog').showModal());
$('#eco-mode').addEventListener('change',()=>{state.quality=$('#eco-mode').checked?'eco':'auto';scene?.setQuality(state.quality==='eco');persist();});
$('#reset-progress').addEventListener('click',()=>$('#reset-dialog').showModal());
$('#confirm-reset').addEventListener('click',()=>{
 epoch++;busy=false;state=fresh();state.introSeen=true;persist();$('#submit-key').disabled=false;$('#submit-final').disabled=false;
 for(const d of document.querySelectorAll('dialog[open]'))d.close();for(let i=0;i<7;i++)$('#word-'+i).value='';$('#proofs').value='';$('#final-feedback').textContent='';
 scene?.endCelebrate();scene?.setQuality(false);scene?.filter('all');document.querySelectorAll('[data-level]').forEach(b=>b.setAttribute('aria-pressed',b.dataset.level==='all'?'true':'false'));
 render();navigate('carte');toast('Les sept sceaux sont à nouveau fermés.');
});
// A second tab never overwrites newer progress after returning to the app.
window.addEventListener('storage',e=>{if(e.key===STORAGE_KEY){state=load();render();for(let i=0;i<7;i++)$('#word-'+i).value=state.drafts[i];$('#proofs').value=state.proofs;scene?.setQuality(state.quality==='eco');}});
function leaveIntro(){
 if(leavingIntro)return;leavingIntro=true;clearTimeout(introTimer);state.introSeen=true;persist();$('#intro').classList.add('leaving');$('#app').inert=false;
 setTimeout(()=>{$('#intro').hidden=true;$('#intro').classList.remove('leaving');leavingIntro=false;$('#open-settings').focus({preventScroll:true});if(state.validated.length===7&&!state.finalSeen)startCeremony();},reduced.matches?0:600);
}
function playIntro(){clearTimeout(introTimer);$('#intro').hidden=false;$('#app').inert=true;$('#skip-intro').focus({preventScroll:true});introTimer=setTimeout(leaveIntro,reduced.matches?700:3300);}
$('#skip-intro').addEventListener('click',leaveIntro);$('#intro').addEventListener('keydown',e=>{if(e.key==='Escape')leaveIntro();if(e.key==='Tab'){e.preventDefault();$('#skip-intro').focus();}});
$('#replay-intro').addEventListener('click',()=>{$('#settings-dialog').close();playIntro();});
scene=new LouvreScene({canvas:$('#louvre'),container:$('#scene-wrap'),onSelect:openMission,onQuality:label=>{$('#graphic-status').textContent=label.toUpperCase();}});
scene.setQuality(state.quality==='eco');
$('#reset-camera').addEventListener('click',()=>scene.resetCamera());
document.querySelectorAll('[data-level]').forEach(b=>b.addEventListener('click',()=>{document.querySelectorAll('[data-level]').forEach(o=>o.setAttribute('aria-pressed',String(o===b)));scene.filter(b.dataset.level);}));
render();navigate(location.hash.slice(1)||'carte',false);persist();
if(state.introSeen){$('#intro').hidden=true;$('#app').inert=false;if(state.validated.length===7&&!state.finalSeen)startCeremony();}else playIntro();
function updateOffline(){
 $('#offline-status').textContent=offlineReady?(navigator.onLine?'PRÊT HORS LIGNE':'HORS LIGNE · PRÊT'):(navigator.onLine?'PRÉPARATION HORS LIGNE':'HORS LIGNE NON PRÊT');
 $('#cache-warning').hidden=offlineReady;
}
async function checkOffline(reg){
 const worker=reg.active;if(!worker)return;
 const channel=new MessageChannel();const timer=setTimeout(()=>{offlineReady=false;updateOffline();},8000);
 channel.port1.onmessage=e=>{clearTimeout(timer);offlineReady=e.data?.type==='OFFLINE_READY';updateOffline();channel.port1.close();};worker.postMessage({type:'CHECK_OFFLINE'},[channel.port2]);
}
async function prepareOffline(){
 updateOffline();if(!('serviceWorker' in navigator)||!window.isSecureContext){$('#offline-status').textContent='HORS LIGNE INDISPONIBLE';return;}
 try{
  const reg=await navigator.serviceWorker.register(new URL('../service-worker.js',import.meta.url),{scope:new URL('../',import.meta.url).pathname,updateViaCache:'none'});
  await navigator.serviceWorker.ready;await checkOffline(reg);
  navigator.serviceWorker.addEventListener('controllerchange',()=>checkOffline(reg));
 }catch{$('#offline-status').textContent='HORS LIGNE NON PRÊT';$('#cache-warning').hidden=false;}
}
window.addEventListener('online',()=>{updateOffline();navigator.serviceWorker?.getRegistration().then(reg=>reg&&checkOffline(reg));});window.addEventListener('offline',updateOffline);
prepareOffline();
