# Mettre les Sept Sceaux sur ton iPhone

L’application est prête. Elle doit avoir une adresse web HTTPS pour s’installer et fonctionner hors connexion. Ce guide publie le ZIP sur ton propre compte GitHub sans ordinateur.

## 1. Créer le dépôt

1. Dans Safari, connecte-toi à [GitHub](https://github.com).
2. Crée un dépôt **Public** nommé exactement **sept-sceaux**.
3. Active l’ajout d’un README, puis crée le dépôt. La branche sera normalement `main`.
4. Si les commandes ci-dessous sont cachées, utilise le menu de Safari pour demander la **version pour ordinateur** du site GitHub. L’interface varie selon la largeur de l’écran.

## 2. Envoyer le ZIP

1. Télécharge **Sept_Sceaux_Web_V1.zip** depuis notre conversation et enregistre-le dans **Fichiers**.
2. Dans le dépôt GitHub, choisis **Add file → Upload files**.
3. Sélectionne le fichier ZIP dans Fichiers, **sans le décompresser** et sans changer son nom.
4. Valide avec **Commit changes** sur la branche `main`.

GitHub Pages ne décompresse pas les ZIP de lui-même. L’étape suivante lui donne une petite procédure pour le faire et publier le site.

## 3. Activer GitHub Pages

Dans le dépôt : **Settings → Pages → Build and deployment → Source → GitHub Actions**.

## 4. Ajouter la procédure de publication

Retourne dans **Code → Add file → Create new file**.

Nom du fichier :

```text
.github/workflows/pages.yml
```

Copie tout le bloc ci-dessous, puis **Commit changes** :

```yaml
name: Publier les Sept Sceaux
on:
  push:
    branches: [main]
  workflow_dispatch:
permissions:
  contents: read
  pages: write
  id-token: write
concurrency:
  group: pages
  cancel-in-progress: false
jobs:
  deploy:
    environment:
      name: github-pages
      url: ${{ steps.deployment.outputs.page_url }}
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Préparer le site
        run: |
          mkdir -p _site
          unzip -q Sept_Sceaux_Web_V1.zip -d _site
          test -f _site/index.html
          touch _site/.nojekyll
      - uses: actions/configure-pages@v5
      - uses: actions/upload-pages-artifact@v3
        with:
          path: _site
      - name: Publier
        id: deployment
        uses: actions/deploy-pages@v4
```

Le ZIP est prévu pour cela : `index.html` est à sa racine. Ne publie pas le PDF de corrigés dans ce dépôt.

## 5. Ouvrir le jeu

Dans **Actions**, ouvre « Publier les Sept Sceaux ». Attends que le traitement soit vert. Le lien de publication apparaît dans le déploiement et dans **Settings → Pages**.

L’adresse attendue est :

```text
https://TON-IDENTIFIANT.github.io/sept-sceaux/
```

Remplace `TON-IDENTIFIANT` par ton nom d’utilisateur GitHub. Cette adresse n’existe qu’après la publication réussie : ce guide ne prétend pas qu’elle est déjà en ligne.

## 6. Installer et préparer le hors connexion

1. Ouvre l’adresse du jeu dans **Safari**, avec du réseau.
2. Attends **PRÊT HORS LIGNE** dans la barre de progression.
3. Menu de partage → **Sur l’écran d’accueil**. Selon iOS, active **Ouvrir comme app web** si cette option apparaît, puis ajoute l’icône.
4. Lance le jeu **depuis cette icône**, toujours avec du réseau. Attends de nouveau **PRÊT HORS LIGNE**.
5. Ferme le jeu, active le **mode avion**, puis rouvre l’icône : carte, sceaux et saisie doivent fonctionner.
6. Utilise toujours cette même icône pendant la visite. Ne compte pas sur une synchronisation entre Safari, Edge et la version installée.

Pour vérifier une clé, il faudra toujours la résoudre dans le carnet. L’app ne révèle ni les réponses ni le déchiffrement final.

## Vérification avant le Louvre

- La carte est lisible en portrait ; le glissement tourne légèrement le bâtiment.
- Les sceaux peuvent aussi être ouverts depuis l’onglet **Les sceaux**.
- Le guide « i » explique la sauvegarde et permet d’alléger les graphismes.
- Le mode avion fonctionne après réouverture.
- Après une vraie validation, fermer et rouvrir conserve le sceau.
- Tu gardes le carnet téléchargé dans Fichiers, séparément de l’app.

La conservation hors ligne dépend du stockage de l’iPhone : supprimer l’app ou les données du site peut effacer le cache et la progression. Évite la navigation privée pour cette enquête.

## En cas de problème

**L’adresse affiche 404 :** vérifier que l’action est verte, que Pages utilise GitHub Actions, que le dépôt s’appelle `sept-sceaux` et que le ZIP a gardé son nom exact.

**L’action échoue à la décompression :** le fichier doit s’appeler `Sept_Sceaux_Web_V1.zip`, à la racine du dépôt, sur `main`.

**Le statut hors ligne n’est pas prêt :** garder le réseau actif, rouvrir l’app depuis son icône et attendre. Tester le mode avion seulement après le statut prêt.

**L’application saccade :** ouvrir le guide « i » et activer le mode graphique allégé. L’app possède aussi une réduction automatique des effets.

**Une nouvelle version arrive :** remplacer le ZIP dans le dépôt avec le même nom ; l’action republiera le site. Ouvrir ensuite le jeu avec du réseau et relancer une fois si nécessaire. Conserver le nom du dépôt et la même adresse pour conserver la progression.

## Sources des étapes de publication et d’installation

- [GitHub Pages : choisir la source de publication](https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site)
- [Apple : ajouter un site à l’écran d’accueil](https://support.apple.com/guide/iphone/iph42ab2f3a7/ios)

Les étapes de publication sur ton compte et l’installation physique sur ton iPhone restent à effectuer ; elles ne peuvent pas être validées par une simple simulation de taille d’écran.
