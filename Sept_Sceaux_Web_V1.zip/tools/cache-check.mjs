// Simulation des API du service worker : à compléter par le test en mode avion.
import vm from 'node:vm';import fs from 'node:fs/promises';import assert from 'node:assert/strict';
const root=new URL('../',import.meta.url);
const code=await fs.readFile(new URL('service-worker.js',root),'utf8');
const listeners={},entries=new Map(),stores=new Map();let offline=false,claimed=0,skip=0;
const makeCache=()=>({async addAll(requests){const staged=new Map();for(const req of requests){const url=new URL(req.url);const relative=url.pathname.replace('/sept-sceaux/','')||'index.html';const bytes=await fs.readFile(new URL(relative,root));staged.set(req.url,new Response(bytes));}for(const [k,v]of staged)entries.set(k,v);},async match(req){return entries.get(typeof req==='string'?req:req.url)?.clone();}});
const self={registration:{scope:'https://example.github.io/sept-sceaux/'},location:{origin:'https://example.github.io'},clients:{async claim(){claimed++;}},async skipWaiting(){skip++;},addEventListener(type,cb){listeners[type]=cb;}};
const caches={async open(name){if(!stores.has(name))stores.set(name,makeCache());return stores.get(name);},async keys(){return [...stores.keys()];},async delete(name){return stores.delete(name);}};
vm.runInNewContext(code,{self,caches,URL,Request,Response,Promise,encodeURIComponent,fetch:()=>{if(offline)throw new Error('Offline');return new Response('network');}});
async function fire(type,more={}){let p;listeners[type]({...more,waitUntil(q){p=q;},respondWith(q){p=q;}});return await p;}
await fire('install');await fire('activate');assert.equal(skip,1);assert.equal(claimed,1);
offline=true;for(const url of entries.keys()){const request={url,method:'GET',mode:url.endsWith('/')?'navigate':'cors'};const response=await fire('fetch',{request});assert.equal(response.status,200);}
let message;await fire('message',{data:{type:'CHECK_OFFLINE'},ports:[{postMessage(m){message=m;}}]});assert.equal(message.type,'OFFLINE_READY');
console.log(JSON.stringify({model:'Service worker API simulation, not a browser',cached_assets:entries.size,all_available_with_network_disabled:true,scope:'/sept-sceaux/',ready_signal:true}));
