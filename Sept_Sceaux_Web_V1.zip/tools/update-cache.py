from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parents[1]
files=['./','./index.html','./manifest.json']+['./'+str(p.relative_to(root)) for d in ['src','assets','icons'] for p in sorted((root/d).rglob('*')) if p.is_file() and p.suffix not in ['.txt']]
h=hashlib.sha256()
for f in files[1:]:h.update((root/f.removeprefix('./')).read_bytes())
version=h.hexdigest()[:12]
s='''// Immutable shell version: change this identifier whenever a shipped asset changes.
const VERSION = 'VERSION_PLACEHOLDER';
// Isolate installations hosted at different GitHub Pages subpaths.
const PREFIX = 'sept-sceaux-' + encodeURIComponent(self.registration.scope) + '-';
const CACHE = PREFIX + VERSION;
const FILES = FILES_PLACEHOLDER;
const absolute = p => new URL(p, self.registration.scope).href;
self.addEventListener('install', event => {
 event.waitUntil((async () => {
  const cache = await caches.open(CACHE);
  // Installation is atomic: activation never occurs after a partial shell download.
  await cache.addAll(FILES.map(p => new Request(absolute(p), {cache:'reload'})));
  await self.skipWaiting();
 })());
});
self.addEventListener('activate', event => {
 event.waitUntil((async () => {
  for (const name of await caches.keys()) if (name.startsWith(PREFIX) && name !== CACHE) await caches.delete(name);
  await self.clients.claim();
 })());
});
self.addEventListener('fetch', event => {
 if (event.request.method !== 'GET') return;
 const url = new URL(event.request.url);
 if (url.origin !== self.location.origin || !url.href.startsWith(self.registration.scope)) return;
 event.respondWith((async () => {
  const cache = await caches.open(CACHE);
  if (event.request.mode === 'navigate') {
   return (await cache.match(absolute('./index.html'))) || fetch(event.request);
  }
  return (await cache.match(event.request, {ignoreSearch:true})) || fetch(event.request);
 })());
});
self.addEventListener('message', event => {
 if (event.data?.type !== 'CHECK_OFFLINE') return;
 event.waitUntil((async () => {
  const cache = await caches.open(CACHE);
  const checks = await Promise.all(FILES.map(p=>cache.match(absolute(p))));
  event.ports[0]?.postMessage({type:checks.every(Boolean)?'OFFLINE_READY':'OFFLINE_INCOMPLETE',version:VERSION});
 })());
});
'''.replace('VERSION_PLACEHOLDER',version).replace('FILES_PLACEHOLDER',json.dumps(files,indent=1))
(root/'service-worker.js').write_text(s)
print(len(files),'cached files; version',version)
