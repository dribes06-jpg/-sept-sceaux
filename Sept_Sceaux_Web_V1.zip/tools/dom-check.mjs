// Simulation DOM uniquement : aucun contrôle du rendu CSS ou de Safari réel.
import assert from 'node:assert/strict';import fs from 'node:fs/promises';
import {JSDOM} from 'jsdom';
import {fileURLToPath} from 'node:url';
const root=fileURLToPath(new URL('../',import.meta.url)).replace(/\/$/,'');const html=await fs.readFile(root+'/index.html','utf8');const fixture=JSON.parse(await fs.readFile(process.env.SEPT_TEST_FIXTURE,'utf8'));
const sleep=()=>new Promise(r=>setTimeout(r,15));
function setup(saved){
 const dom=new JSDOM(html,{url:'https://example.github.io/sept-sceaux/',pretendToBeVisual:true});const w=dom.window;
 for(const [key,value]of Object.entries({window:w,document:w.document,navigator:w.navigator,localStorage:w.localStorage,history:w.history,location:w.location,devicePixelRatio:1,ResizeObserver:class{observe(){} disconnect(){}},matchMedia:()=>({matches:true,addEventListener(){}})}))Object.defineProperty(globalThis,key,{value,configurable:true,writable:true});
 w.HTMLCanvasElement.prototype.getContext=()=>null;
 w.HTMLDialogElement.prototype.showModal=function(){this.setAttribute('open','');};
 w.HTMLDialogElement.prototype.close=function(){this.removeAttribute('open');this.dispatchEvent(new w.Event('close'));};w.HTMLElement.prototype.scrollTo=function(){};
 if(saved)w.localStorage.setItem('sept-sceaux.progress.v1',saved);return dom;
}
let dom=setup();await import(root+'/src/app.js?run=1');
const $=s=>document.querySelector(s);const click=s=>$(s).click();
click('#skip-intro');await sleep();
assert.equal($('#app').inert,false);assert.equal($('#progress-label').textContent,'0 / 7 SCEAUX AUTHENTIFIÉS');
click('nav [data-nav="final"]');assert.equal($('#final-locked').hidden,false);assert.equal($('#final-open').hidden,true);
for(let id=1;id<=7;id++){
 click('nav [data-nav="sceaux"]');click(`#mission-list [data-mission="${id}"]`);assert.equal($('#mission-dialog').open,true);
 $('#key-input').value=String(fixture.keys[id-1]===25?24:25);$('#key-form').dispatchEvent(new dom.window.Event('submit',{cancelable:true}));await sleep();assert.equal($('#key-feedback').textContent,'LE SCEAU DEMEURE FERMÉ');
 assert.equal(JSON.parse(localStorage.getItem('sept-sceaux.progress.v1')).validated.length,id-1);
 $('#key-input').value=String(fixture.keys[id-1]);$('#key-form').dispatchEvent(new dom.window.Event('submit',{cancelable:true}));await sleep();assert.equal($('#key-feedback').textContent,'SCEAU AUTHENTIFIÉ');assert.equal($('#key-form').hidden,true);
 click('#mission-done');assert.equal($('#mission-dialog').open,false);
}
assert.equal($('#ceremony-dialog').open,true);click('#enter-final');assert.equal($('#final-open').hidden,false);
const words=fixture.phrase.split(' ');
function setWords(values){values.forEach((value,i)=>{$('#word-'+i).value=value;$('#word-'+i).dispatchEvent(new dom.window.Event('input'));});}
setWords(Array(7).fill('ERREUR'));$('#final-form').dispatchEvent(new dom.window.Event('submit',{cancelable:true}));await sleep();assert.equal($('#final-feedback').textContent,'LE MESSAGE RESTE SCELLÉ');assert.equal($('#ending').hidden,true);
setWords(words);$('#final-form').dispatchEvent(new dom.window.Event('submit',{cancelable:true}));await sleep();assert.equal($('#ending').hidden,false);
const saved=localStorage.getItem('sept-sceaux.progress.v1');assert.ok(!JSON.parse(saved).keys);
dom.window.close();dom=setup(saved);await import(root+'/src/app.js?run=2');assert.equal($('#intro').hidden,true);assert.equal($('#progress-label').textContent,'7 / 7 SCEAUX AUTHENTIFIÉS');assert.equal($('#ending').hidden,false);
click('#open-settings');click('#reset-progress');assert.equal($('#reset-dialog').open,true);click('#confirm-reset');assert.equal($('#progress-label').textContent,'0 / 7 SCEAUX AUTHENTIFIÉS');assert.equal($('#final-open').hidden,true);assert.equal(JSON.parse(localStorage.getItem('sept-sceaux.progress.v1')).completed,false);
console.log(JSON.stringify({model:'DOM simulated (no layout, no physical device)',correct_seals:7,wrong_seals:7,final_gating:'passed',final_wrong_and_correct:'passed',reload_state_restore:'passed',confirmed_reset:'passed',fallback_map:'passed'}));dom.window.close();process.exit(0);
