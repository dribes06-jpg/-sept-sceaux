// Test réel à exécuter sur une adresse servie après installation des navigateurs.
// Aucun corrigé embarqué. Ne pas conserver SEPT_TEST_FIXTURE dans le dépôt public.
import {chromium,webkit} from 'playwright';
import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
const fixture=JSON.parse(await fs.readFile(process.env.SEPT_TEST_FIXTURE,'utf8'));
const url=process.env.SEPT_TEST_URL || 'http://localhost:8080/sept-sceaux/';
const engine=process.env.SEPT_TEST_ENGINE==='webkit'?webkit:chromium;
const browser=await engine.launch({headless:true});
const context=await browser.newContext({viewport:{width:393,height:852},deviceScaleFactor:2,isMobile:true,hasTouch:true,reducedMotion:'reduce'});
let page=await context.newPage();const errors=[];page.on('pageerror',e=>errors.push(e.message));
await page.goto(url);await page.locator('#intro').waitFor({state:'hidden'});
await page.locator('#offline-status').filter({hasText:'PRÊT HORS LIGNE'}).waitFor();
for(const viewport of [{width:375,height:667},{width:390,height:844},{width:393,height:852},{width:430,height:932},{width:852,height:393}]){
 await page.setViewportSize(viewport);await page.waitForTimeout(80);
 const bounds=await page.locator('body').evaluate(el=>({width:el.scrollWidth,viewport:innerWidth}));assert.ok(bounds.width<=bounds.viewport);
 assert.ok(await page.locator('#next-mission').isVisible());
}
await page.setViewportSize({width:393,height:852});
// Controlled pointer drag; a real multi-touch pinch still needs a device test.
const canvas=await page.locator('#louvre').boundingBox();
if(canvas){await page.mouse.move(canvas.x+canvas.width*.4,canvas.y+canvas.height*.55);await page.mouse.down();await page.mouse.move(canvas.x+canvas.width*.65,canvas.y+canvas.height*.56,{steps:8});await page.mouse.up();await page.locator('#reset-camera').click();}
for(let id=1;id<=7;id++){
 await page.locator('nav [data-nav="sceaux"]').tap();await page.locator(`#mission-list [data-mission="${id}"]`).tap();
 await page.locator('#key-input').fill(String(fixture.keys[id-1]===25?24:25));await page.locator('#submit-key').tap();
 await page.getByText('LE SCEAU DEMEURE FERMÉ',{exact:true}).waitFor();
 assert.equal(await page.locator('#progress-label').innerText(),`${id-1} / 7 SCEAUX AUTHENTIFIÉS`);
 await page.locator('#key-input').fill(String(fixture.keys[id-1]));await page.locator('#submit-key').tap();await page.getByText('SCEAU AUTHENTIFIÉ',{exact:true}).waitFor();
 await page.locator('#mission-done').tap();
}
await page.locator('#ceremony-dialog').waitFor();await page.locator('#enter-final').tap();
for(let i=0;i<7;i++)await page.locator('#word-'+i).fill('ERREUR');
await page.locator('#submit-final').tap();await page.getByText('LE MESSAGE RESTE SCELLÉ',{exact:true}).waitFor();
for(const [i,word]of fixture.phrase.split(' ').entries())await page.locator('#word-'+i).fill(word);
await page.locator('#submit-final').tap();await page.locator('#ending').waitFor();
await page.close();await context.setOffline(true);page=await context.newPage();await page.goto(url);await page.locator('#progress-label').filter({hasText:'7 / 7'}).waitFor();
await page.locator('nav [data-nav="final"]').tap();await page.locator('#ending').waitFor();
await page.locator('#open-settings').tap();await page.locator('#reset-progress').tap();await page.locator('#confirm-reset').tap();
await page.locator('#progress-label').filter({hasText:'0 / 7'}).waitFor();
await page.reload();await page.locator('#progress-label').filter({hasText:'0 / 7'}).waitFor();assert.deepEqual(errors,[]);
console.log('Parcours, refus, final, viewport, fermeture d’onglet, hors ligne et reset : OK. Installation sur iPhone physique à vérifier séparément.');
await browser.close();
