// Test de logique reproductible. Aucun corrigé n’est livré dans ce fichier.
// SEPT_TEST_FIXTURE doit désigner un JSON privé {"keys":[7 entiers],"phrase":"..."}.
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import {verifyKey, normalizeKey, verifyMessage} from '../src/crypto.js';
import {sanitize,fresh} from '../src/storage.js';
const file=process.env.SEPT_TEST_FIXTURE;
if(!file)throw new Error('Définir SEPT_TEST_FIXTURE vers un fichier privé extérieur au dépôt. Ne jamais publier les corrigés.');
const fixture=JSON.parse(await fs.readFile(file,'utf8'));
assert.equal(fixture.keys.length,7);
let count=0;
for(let id=1;id<=7;id++)for(let value=1;value<=25;value++){
 assert.equal(await verifyKey(id,String(value)),value===fixture.keys[id-1]);count++;
}
for(const value of ['',0,26,-1,'1.0','2e1','+3','abc','100','3 0'])assert.equal(normalizeKey(value),null);
for(let id=1;id<=7;id++){
 assert.equal(await verifyKey(id,String(fixture.keys[id-1]).padStart(2,'0')),true);
 assert.equal(await verifyKey(id,` ${fixture.keys[id-1]} `),true);
}
assert.equal(await verifyMessage(fixture.phrase),true);
assert.equal(await verifyMessage(fixture.phrase.toLowerCase()),true);
assert.equal(await verifyMessage('UNE MAUVAISE PHRASE'),false);
assert.equal(await verifyMessage(''),false);
assert.deepEqual(sanitize({version:1,validated:[1,1,0,8,'2',3.5,7]}).validated,[1,7]);
assert.equal(sanitize({version:1,validated:[1],completed:true}).completed,false);
assert.equal(sanitize({version:1,validated:[1],finalSeen:true}).finalSeen,false);
assert.deepEqual(sanitize(JSON.parse(JSON.stringify(fresh()))).validated,[]);
console.log(`${count} candidats de clés contrôlés ; formats, message et état restauré : OK.`);
