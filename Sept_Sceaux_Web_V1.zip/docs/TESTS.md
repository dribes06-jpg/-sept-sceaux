# Bilan des contrôles — V1 du 20 septembre 2026

Ce bilan distingue des tests exécutés et des essais à réaliser. Aucun test sur iPhone physique ni mesure de 60 fps n’a été réalisé.

## Exécuté et réussi

| Contrôle | Méthode | Résultat |
|---|---|---|
| Sept validateurs numériques | Exécution réelle du module cryptographique, 25 candidats par sceau | 175 comparaisons réussies ; une seule valeur acceptée par sceau |
| Formats hors plage ou non entiers | Dix entrées : vide, hors plage, décimal, notation exponentielle, etc. | Refus |
| Espaces et zéro initial | 14 contrôles sur les clés attendues | Normalisation cohérente |
| Message final | Phrase de référence, minuscules, accents, œ, phrases fausses/incomplètes/inversées | Acceptation/refus attendus |
| Sept bons et sept mauvais essais dans l’interface | Simulation DOM avec le vrai `app.js`, dialogues simulés et repli SVG | Refus uniforme ; progression seulement après succès |
| Verrouillage du final | Même simulation | Fermé avant sept validations, ouvert après |
| Message faux puis correct dans le formulaire | Même simulation | Aucun retour par mot ; succès global uniquement |
| Restauration et reset | Nouvelle instance DOM avec stockage restauré, puis reset confirmé | Progression restaurée puis effacée |
| État malformé | Validation de doublons, IDs invalides, final prématuré | État nettoyé |
| Cache hors connexion | Simulation des API service worker avec véritables fichiers, réseau désactivé | Les 19 ressources précachées restent disponibles |
| Signal « Prêt hors ligne » | Même simulation | Envoyé après contrôle complet des entrées |
| Manifest et chemins | Contrôle des fichiers, chemins relatifs, scope `/sept-sceaux/` | Cohérents |
| Réponses en clair | Inspection des fichiers publiés et recherche de la phrase/table de clés de référence | Aucune réponse préinscrite en clair |
| Syntaxe JavaScript | Analyse Node des modules écrits | Valide |

Les données privées de référence utilisées pour ces essais ne sont pas dans l’archive.

## Limite rencontrée

Le navigateur distant disponible n’a pas pu ouvrir l’adresse de développement locale (`ERR_BLOCKED_BY_CLIENT`). Un navigateur local n’a pas pu démarrer dans cet environnement. Aucun blocage n’a été contourné. Les essais de DOM et d’API de cache ci-dessus sont des simulations ; ils ne remplacent pas un navigateur réel.

## À exécuter sur l’adresse publiée

- Rendu 3D réel et absence d’erreurs de console.
- Formats 375×667, 390×844, 393×852, 430×932 et 852×393.
- Toucher les sept repères, tourner et pincer la carte, vérifier les cibles tactiles.
- Ouvrir chaque sceau puis revenir : cadrage d’ensemble restauré à chaque fois.
- Vérifier les contrastes, les libellés, le clavier numérique, les safe areas et le Dynamic Island sur iPhone.
- Vérifier les sept bonnes clés et des clés fausses en navigateur réel ; aucune réponse ou proximité révélée.
- Fermer complètement l’application installée, la rouvrir, puis redémarrer l’iPhone : progression conservée.
- Installer depuis Safari ; lancer une première fois l’icône avec réseau et attendre « Prêt hors ligne ».
- Réouvrir en mode avion, naviguer, valider et réinitialiser ; vérifier aussi un brouillon de message.
- Tester `prefers-reduced-motion`, le mode graphique allégé et un contexte WebGL indisponible.
- Mesurer la fluidité et l’échauffement sur appareil réel. Le plafond visé de 60 fps n’est pas une performance mesurée.

## Scripts livrés

`tools/smoke.mjs` teste les validateurs ; `tools/dom-check.mjs` teste le parcours en simulation ; `tools/cache-check.mjs` simule le service worker. Ces contrôles ont été exécutés dans l’environnement de développement.

`tools/browser-check.mjs` fournit le parcours automatisé pour un navigateur réel, à lancer après publication. **Ce script est livré mais n’a pas pu être exécuté ici.** Il teste plusieurs viewports, des interactions tactiles simples, les validations, la fermeture/réouverture d’onglet, le hors ligne et le reset. Il ne remplace pas une installation physique iOS ni un geste de pincement à deux doigts.

Pour un développeur disposant de Node :

```sh
npm install
SEPT_TEST_FIXTURE=/chemin/prive/fixtures.json npm test
npx playwright install chromium webkit
SEPT_TEST_FIXTURE=/chemin/prive/fixtures.json SEPT_TEST_URL=https://votre-adresse/sept-sceaux/ npm run test:browser
SEPT_TEST_FIXTURE=/chemin/prive/fixtures.json SEPT_TEST_URL=https://votre-adresse/sept-sceaux/ SEPT_TEST_ENGINE=webkit npm run test:browser
```

Les fixtures doivent contenir les sept clés et la phrase de référence dans un fichier privé extérieur au dépôt. Ne pas les ajouter à GitHub et ne pas les afficher dans les journaux. Le rapport de test ne doit indiquer que les succès et les échecs, pas les valeurs attendues.
