# Le Secret des Sept Sceaux — architecture V1

## Référence analysée

Carnet Joueurs « Regards croisés », version de 12 pages. Lecture intégrale avant développement : prologue (p. 2), carte éclatée (p. 3), parcours (p. 4), sept missions (p. 5–11), sept fragments et règle finale (p. 12). Les illustrations de la plaquette ne servent jamais à vérifier une observation.

## Choix techniques

Application statique HTML/CSS/JavaScript en modules ES. Three.js 0.180.0 est distribué dans `assets/vendor` avec sa licence MIT ; aucune dépendance CDN à l’exécution, aucune compilation obligatoire, aucun serveur applicatif, aucun compte, aucun suivi analytique. Polices DejaVu réduites aux caractères utiles et servies localement, avec leur licence.

- `src/data.js` : noms, salles, pages, ordre de visite, positions indicatives et fragments chiffrés.
- `src/scene.js` : géométrie procédurale et gestes ; repli sur un plan SVG si WebGL est indisponible.
- `src/app.js` : navigation, dialogues, validations et séquence finale.
- `src/crypto.js` et `src/verifiers.js` : normalisation et vérification des empreintes.
- `src/storage.js` : sauvegarde locale versionnée et validation des données restaurées.
- `service-worker.js` : cache complet de l’application, limité à son sous-répertoire.

## Direction artistique et écrans

Bleu pétrole profond `#081b23`, ivoire `#f3ecdc`, or `#c8a76d`. Typographie éditoriale pour les titres, sans sérif lisible pour les commandes. Traits fins, cercles gravés et éclairage discret. Aucun confetti, effet sonore imposé ou score infantilisant.

1. Introduction brève (environ 4 secondes avec transition), toujours passable. Elle n’est pas rejouée automatiquement après la première visite.
2. Carte 3D principale : silhouette éclatée, sept sceaux, choix du niveau, prochaine étape et progression.
3. Liste des sceaux dans l’ordre de visite ; alternative accessible à la sélection spatiale.
4. Fiche de mission : ambiance, lieu et page du carnet ; saisie numérique uniquement, sans reproduction de l’énigme.
5. Chambre finale, verrouillée jusqu’aux sept validations, puis sept champs de déchiffrement et contrôle global du message.
6. Guide : installation, statut hors ligne, mode graphique allégé et reset avec confirmation.

La navigation principale conserve trois entrées : Louvre, Sceaux, Final. Les missions s’ouvrent dans un dialogue natif, utilisable au clavier et avec un lecteur d’écran. Fermer une mission rétablit la caméra d’ensemble. Le sélecteur de niveaux filtre les repères, sans interdire l’accès aux autres missions par la liste.

## Missions et ordre de visite

| Sceau | Mission | Œuvres | Aile | Niveau | Salle | Page |
|---|---|---|---|---|---|---|
| 1 | L’anatomie du gardien | Sphinx de Tanis | Sully | −1 | 338 | 5 |
| 2 | Le cycle des récoltes | Mastaba d’Akhethétep | Sully | 0 | 333 | 6 |
| 3 | Le miroir de Sekhmet | Deux Sekhmet et relevé du Sphinx | Sully | 0 | 324 | 7 |
| 4 | Trois témoins, trois sceaux | Scribe / Sépa / Nésa | Sully | 1 | 635 | 8 |
| 5 | L’équilibre du juge | Code de Hammurabi | Richelieu | 0 | 227 | 9 |
| 6 | Le lion et le gardien ailé | Taureau ailé / héros au lion | Richelieu | 0 | 229 | 10 |
| 7 | Le fragment retrouvé | Victoire et main séparée | Denon | 1 | 703 | 11 |

Ordre de visite : **1 → 2 → 3 → 5 → 6 → 4 → 7**. Ordre du final : **1 → 2 → 3 → 4 → 5 → 6 → 7**. Les clés acceptées sont des entiers de 1 à 25 ; les réponses ne sont pas consignées dans ce dossier.

Fragments repris exactement : `OHV`, `XNDEANB`, `WI`, `KXIHGWXGM`, `YCIVL`, `FE`, `ANEQDHQ`. Le joueur applique lui-même les décalages du carnet. Aucune correction mot par mot et aucun déchiffrement automatique. Les rapprochements culturels peuvent être notés mais ne sont pas évalués par une IA.

## Stratégie 3D et performances

Empreinte volontairement schématique inspirée de la carte du carnet : Richelieu au nord, Denon au sud, cour Carrée encadrée par Sully à l’est, cour Napoléon et pyramide à l’ouest. Les niveaux sont espacés verticalement. Les positions sont des repères sectoriels, pas des coordonnées topographiques ou un guidage GPS.

Surfaces et façades regroupées par étage en géométries fusionnées. Pas d’ombres dynamiques, post-traitement ou textures photographiques. Projection orthographique, rotation et inclinaison bornées, zoom limité. Repères HTML de 46 px avec leaders pour conserver des cibles tactiles séparées. Retour caméra indépendant de la sélection. Une unique scène ; animation suspendue lorsque la page est masquée ou que la carte n’est pas affichée.

Résolution plafonnée à 1,6 fois la résolution CSS. Échantillonnage du temps entre images : si la moyenne dépasse 28 ms sur 150 images exploitables, résolution abaissée à 1 et effets réduits. Mode allégé manuel, particules masquées et cadence plafonnée à 30 fps. `prefers-reduced-motion` supprime les mouvements décoratifs et l’inertie de transition. Viser 60 fps n’est pas une mesure sur iPhone réel.

## Réponses, progression et confidentialité

Empreinte SHA-256 unique par sceau avec sel aléatoire de 24 octets et contexte de domaine. La phrase finale possède une empreinte distincte. Aucune réponse correcte préinscrite en clair, aucune table de corrigés et aucun outil de génération des réponses livré. Les fixtures privées de contrôle ne sont pas dans le dépôt. Le sel n’est pas une clé secrète : 25 valeurs restent testables par un utilisateur qui analyse le programme. Une application cliente ne peut empêcher cela ni rendre sa progression infalsifiable.

Une erreur de clé valide affiche toujours exactement « LE SCEAU DEMEURE FERMÉ ». Une erreur de message affiche toujours « LE MESSAGE RESTE SCELLÉ ». La validation de format ne rappelle que la plage publique 1–25. Aucun signe de proximité ou de correction partielle.

`localStorage` garde les sceaux validés, la date de début, l’introduction vue, la cérémonie vue, les brouillons du joueur et le choix graphique. Les clés numériques saisies ne sont pas conservées. Les brouillons de fin, saisis par le joueur, restent localement en clair. Une panne de stockage est signalée. Le reset vide la progression mais conserve les fichiers hors ligne.

## Hors connexion et sous-répertoire

Manifest, imports, icônes et cache utilisent des chemins relatifs. Le scope de service worker est celui du répertoire de l’application, par exemple `/sept-sceaux/`. Le cache est isolé par scope et version. L’installation attend le téléchargement de tous les fichiers avant activation. « Prêt hors ligne » apparaît seulement après vérification de chaque entrée de cache.

La première ouverture nécessite HTTPS et du réseau. L’app doit être lancée depuis l’icône installée et son cache vérifié avant la visite. La suppression des données du site par l’utilisateur ou le système peut supprimer le cache et la progression. Les restrictions de stockage d’iOS ne peuvent pas être contournées par cette application.

## Références techniques

- [Three.js](https://threejs.org/docs/)
- [Service workers, MDN](https://developer.mozilla.org/en-US/docs/Web/API/Service_Worker_API/Using_Service_Workers)
- [GitHub Pages : source de publication](https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site)
- [Apple : ajouter un site sur l’écran d’accueil](https://support.apple.com/guide/iphone/iph42ab2f3a7/ios)
